<h1>이의이승이메일테스트</h1>
<br>
<div>해당url로 접속해 주시길 바랍니다</div>
<div><?php echo e($data['url']); ?></div>
<div>감사합니다</div>
<?php /**PATH D:\workspace\team5\resources\views/mail/mail_form.blade.php ENDPATH**/ ?>