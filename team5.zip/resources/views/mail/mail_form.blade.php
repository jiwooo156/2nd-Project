<h1>이의이승 가입 이메일</h1>
<br>
<div>해당url로 접속해 주시길 바랍니다</div>
<div>{{ $data['url'] }}</div>
<div>감사합니다</div>
