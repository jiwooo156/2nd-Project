<template lang="">
	<div class="post">
		포스트
	</div>
</template>
<script>
export default {
	name: "PostComponent",
}
</script>
<style lang="">
	
</style>