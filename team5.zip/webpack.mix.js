const mix = require('laravel-mix');

mix.js('resources/js/app.js', 'public/js')
// 믹스 사용할때 뷰 버전 3
    .vue({
        version: 3,
    })
    .postCss('resources/css/app.css', 'public/css', [
        //
    ]);
